<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class rich_fq extends Widget_Base {

    public function get_name() {
        return 'rich-fq';
    }

    public function get_title() {
        return __( 'Faq', 'rich-consulting' );
    }
    public function get_categories() {
        return [ 'richelement-addons' ];
    }
    public function get_icon() {
        return 'eicon-person';
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => __( 'Content', 'rich-consulting' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        $repeater = new \Elementor\Repeater();
        $repeater->add_control(
            'title',
            [
                'label' => __( 'Title', 'rich-consulting' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Why Should We Press Get A Quote Button?', 'rich-consulting' ),
            ]
        );
        $repeater->add_control(
            'info',
            [
                'label' => __( 'Content', 'rich-consulting' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore Ut enim ad minim veniam.', 'rich-consulting' ),
            ]
        );
        $this->add_control(
            'member_list',
            [
                'label' => __( 'Faq List', 'rich-consulting' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'title' => __( 'Why Should We Press Get A Quote Button?', 'rich-consulting' ),
                    ],
                    [
                        'title' => __( 'Why Should We Press Get A Quote Button?', 'rich-consulting' ),
                    ],
                    [
                        'title' => __( 'Why Should We Press Get A Quote Button?', 'rich-consulting' ),
                    ],
                    [
                        'title' => __( 'Why Should We Press Get A Quote Button?', 'rich-consulting' ),
                    ],
                ],
                'title_field' => '{{{ title }}}',
            ]
        );
        $this->end_controls_section();
        $this->start_controls_section(
            'section_style',
            [
                'label' => __( 'Style', 'rich-consulting' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'title_color',
            [
                'label' => __( 'Title Color', 'rich-consulting' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .accordion .acc-btn p' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'title_fonts',
                'label' => __( 'Title Typography', 'rich-consulting' ),
                'selector' => '{{WRAPPER}} .accordion .acc-btn p',
            ]
        );
        $this->add_control(
            'des_color',
            [
                'label' => __( 'Content Color', 'rich-consulting' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .accordion-box .accordion .acc-content p' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'des_fonts',
                'label' => __( 'Content Typography', 'rich-consulting' ),
                'selector' => '{{WRAPPER}} .accordion-box .accordion .acc-content p',
            ]
        );
        $this->add_control(
            'social_bg',
            [
                'label' => __( 'Box BG', 'rich-consulting' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'after',
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'team_socials_bg',
                'label' => __( 'Team Social BG', 'rich-consulting' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .accordion .acc-btn.collapsed .toggle-icon',
            ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $uid = uniqid();
        echo '<div class="accordion-box style-one" id="accordion-'.$uid.'">';
        if ( $settings['member_list'] ) {
            $index = 0;
            foreach ($settings['member_list'] as $members) {
                $index++;
                if ($index == 1){
                    $class = 'show';
                    $class2 = '';
                }else{
                    $class = '';
                    $class2 = 'collapsed';
                }
                echo'<article class="accordion">
                        <div class="acc-btn '.$class2.'" id="heading'.$members['_id'].'" data-toggle="collapse" data-target="#collapse'.$members['_id'].'">
                            <p class="title">'.$members['title'].'</p>
                            <div class="toggle-icon">
                                <i class="plus fas fa-arrow-circle-right"></i>
                            </div>
                        </div>
                        <div class="acc-content collapse '.$class.'" id="collapse'.$members['_id'].'" data-parent="#accordion-'.$uid.'">
                            <div class="text"><p>'.$members['info'].'</p></div>
                        </div>
                    </article>';
                    }
                }
            echo'</div>';
    }

    protected function _content_template() {
    }



    protected function content_template() {}

    public function render_plain_content( $instance = [] ) {}

}
Plugin::instance()->widgets_manager->register_widget_type( new rich_fq() );
?>