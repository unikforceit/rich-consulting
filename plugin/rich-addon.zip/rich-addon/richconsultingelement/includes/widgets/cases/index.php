<?php

namespace Elementor;

if (!defined('ABSPATH')) 
    exit; // Exit if accessed directly


class cases_filter extends Widget_Base {

    public function get_name() {
        return 'cases-filter';
    }
 
    public function get_title() {
        return __('Cases Filter', 'rich-consulting');
    }

    public function get_icon() {
        return 'eicon-form-horizontal';
    }

    public function get_categories() {
        return ['richelement-addons'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_content',
            [
                'label' => __('General', 'rich-consulting'),
            ]
        );

        $this->add_control(
            'cat',
            [
                'label' => __('Category', 'rich-consulting'),
                'type' => Controls_Manager::SELECT2,
                'options' => ae_drop_cat('case_category'),
                'label_block' => true,
                'multiple' => true,
            ]
        );
        $this->add_control(
            'show_cat',
            [
                'label' => esc_html__( 'Show Category', 'rich-consulting' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => esc_html__( '5', 'rich-consulting' ),
            ]
        );
        $this->add_control(
            'post_per',
            [
                'label' => esc_html__( 'Post Per Tab', 'rich-consulting' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => esc_html__( '5', 'rich-consulting' ),
            ]
        );
        $this->end_controls_section();
        
        $this->start_controls_section(
            'section_settings',
            [
                'label' => __( 'General', 'rich-consulting' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'post_title_color',
            [
                'label' => __( 'Title Color', 'rich-consulting' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .post-filter li span' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'post_titlea_color',
            [
                'label' => __( 'Title Active Color', 'rich-consulting' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .post-filter li:hover span, .post-filter li.active span' => 'color: {{VALUE}}; border-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'ttih',
                'label' => __( 'Title Typography', 'rich-consulting' ),
                'selector' => '{{WRAPPER}} .post-filter li span',
            ]
        );
        $this->add_control(
            'hh_c',
            [
                'label' => __( 'Heading Color', 'rich-consulting' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .all-cause .single-item .inner-box .image-box .overlay-box h4' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'ttihaa',
                'label' => __( 'Heading Typography', 'rich-consulting' ),
                'selector' => '{{WRAPPER}} .all-cause .single-item .inner-box .image-box .overlay-box h4',
            ]
        );
        $this->add_control(
            'hh_caa',
            [
                'label' => __( 'Category Color', 'rich-consulting' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .all-cause .single-item .inner-box .overlay-box p' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'ttihaaccc',
                'label' => __( 'Category Typography', 'rich-consulting' ),
                'selector' => '{{WRAPPER}} .all-cause .single-item .inner-box .overlay-box p',
            ]
        );
        $this->add_control(
            'icon_cb',
            [
                'label' => __( 'Overlay BG', 'rich-consulting' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .all-cause .single-item .inner-box .image-box .overlay-box' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->end_controls_section();

    }
        
    protected function render(){

        $settings = $this->get_settings();

echo '<section class="all-cause">
        <div class="post-filter-container has-filterizr">
            <ul class="post-filter list-inline">';
                    $tax_args = array(
                        'taxonomy'      => 'case_category',
                        'number'        => $settings['show_cat'],
                        'include'        => $settings['cat'],
                    );
                    $categories = get_terms($tax_args);
                    echo '<li data-filter="all" class="active"> <span>All</span></li>';
                    foreach($categories as $category) {
                        echo '<li data-filter="'.$category->term_id.'"> <span>' . $category->name . '</span></li>';
                     }
            echo '</ul>

            <div class="row filter-container">';
                    $the_query = new \WP_Query(array(
                        'post_type' => 'cases',
                        'posts_per_page' => $settings['post_per'],
                        'tax_query' => array(
                            array(
                                'taxonomy' => 'case_category',
                                'field' => 'term_id',
                                'terms' => $settings['cat'],
                            )
                        )
                    ));
                    if ($the_query->have_posts()) {
                        while ($the_query->have_posts()) {
                            $the_query->the_post();
                    echo '<div class="col-md-4 col-sm-6 col-xs-12 filtr-item" data-category="' . post_category_id('case_category') . '">
                    <div class="single-item">
                        <div class="inner-box">
                            <div class="image-box">
                                <a href="'.get_the_permalink().'">';
                            if (has_post_thumbnail()) {
                                the_post_thumbnail('full');
                            }
                            echo '</a>
                                <div class="overlay-box center">
                                    <a href="'.get_the_permalink().'"><h4>'.get_the_title().'</h4></a>
                                    <p>'.richconsulting_get_category_link('case_category').'</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>';
                        }
                        wp_reset_query();
                    }
            echo '</div>
        </div>
</section>
';
    }


}
Plugin::instance()->widgets_manager->register_widget_type( new cases_filter() );