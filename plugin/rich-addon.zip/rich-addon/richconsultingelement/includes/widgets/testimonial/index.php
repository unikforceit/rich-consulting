<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class rich_testimonial extends Widget_Base {

    public function get_name() {
        return 'rich-testimonial';
    }

    public function get_title() {
        return __( 'Testimonial', 'rich-consulting' );
    }
    public function get_categories() {
        return [ 'richelement-addons' ];
    }
    public function get_icon() {
        return 'eicon-person';
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => __( 'Content', 'rich-consulting' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'slide_number',
            [
                'label' => __('Slide Number', 'rich-consulting'),
                'type' => Controls_Manager::NUMBER,
                'default' => 1,
            ]
        );
        $this->add_control(
            'layout',
            [
                'label' => __( 'Layout', 'rich-consulting' ),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'one' => [
                        'title' => __( 'One', 'rich-consulting' ),
                        'icon' => 'eicon-form-horizontal',
                    ],
                    'two' => [
                        'title' => __( 'Two', 'rich-consulting' ),
                        'icon' => 'eicon-post-slider',
                    ],
                    'three' => [
                        'title' => __( 'Three', 'rich-consulting' ),
                        'icon' => 'fas fa-star',
                    ],
                ],
                'default' => 'one',
                'toggle' => true,
            ]
        );
        $repeater = new \Elementor\Repeater();
        $repeater->add_control(
            'member_name',
            [
                'label' => __( 'Name', 'rich-consulting' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Patrick Reed', 'rich-consulting' ),
            ]
        );
        $repeater->add_control(
            'member_designation',
            [
                'label' => __( 'Designation', 'rich-consulting' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Chairman, Kollo Company LTD.', 'rich-consulting' ),
            ]
        );
        $repeater->add_control(
            'member_info',
            [
                'label' => __( 'Comment', 'rich-consulting' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __( 'Far far away, behind the word mountains, far from the countries 
                                    Vokalia and Consonantia, there live the blinds  and Separated 
                                    they live in Bookmarksgrove right at the coast of the Semantics, 
                                    language ocean. A small river named Duden flows their place and 
                                    it with the necessary regelialia. It is a country.', 'rich-consulting' ),
            ]
        );
        $repeater->add_control(
            'member_photo', [
                'label' => __( 'Photo', 'rich-consulting' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );
        $this->add_control(
            'member_list',
            [
                'label' => __( 'Client List', 'rich-consulting' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'member_name' => __( 'Patrick Reed', 'rich-consulting' ),
                    ],
                    [
                        'member_name' => __( 'Patrick Reed', 'rich-consulting' ),
                    ],
                    [
                        'member_name' => __( 'Patrick Reed', 'rich-consulting' ),
                    ],
                    [
                        'member_name' => __( 'Patrick Reed', 'rich-consulting' ),
                    ],
                    [
                        'member_name' => __( 'Patrick Reed', 'rich-consulting' ),
                    ],

                ],
                'title_field' => '{{{ member_name }}}',
            ]
        );
        $this->end_controls_section();
        $this->start_controls_section(
            'section_style',
            [
                'label' => __( 'Style', 'rich-consulting' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'title_color',
            [
                'label' => __( 'Title Color', 'rich-consulting' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial .testimonial-item .author .title h5, 
                    {{WRAPPER}} .testimonial-style2 .testimonial-item .author .title h5' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'title_fonts',
                'label' => __( 'Title Typography', 'rich-consulting' ),
                'selector' => '{{WRAPPER}} .testimonial .testimonial-item .author .title h5, 
                {{WRAPPER}} .testimonial-style2 .testimonial-item .author .title h5',
            ]
        );
        $this->add_control(
            'des_color',
            [
                'label' => __( 'Designation Color', 'rich-consulting' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial .testimonial-item .author .title p, 
                    {{WRAPPER}} .testimonial-style2 .testimonial-item .author .title p' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'des_fonts',
                'label' => __( 'Designation Typography', 'rich-consulting' ),
                'selector' => '{{WRAPPER}} .testimonial .testimonial-item .author .title p, 
                {{WRAPPER}} .testimonial-style2 .testimonial-item .author .title p',
            ]
        );
        $this->add_control(
            'inf_color',
            [
                'label' => __( 'Info Color', 'rich-consulting' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial .testimonial-item .content p, 
                    {{WRAPPER}} .testimonial-style2 .testimonial-item .content p' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'inf_fonts',
                'label' => __( 'Info Typography', 'rich-consulting' ),
                'selector' => '{{WRAPPER}} .testimonial .testimonial-item .content p, 
                {{WRAPPER}} .testimonial-style2 .testimonial-item .content p',
            ]
        );
        $this->add_control(
            'social_bg',
            [
                'label' => __( 'Nav BG', 'rich-consulting' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'after',
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'team_socials_bg',
                'label' => __( 'Team Social BG', 'rich-consulting' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .testimonial .owl-nav button:hover i, 
                {{WRAPPER}} .testimonial-style2 .owl-dots .owl-dot span',
            ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        $option = [
            'item' => $settings['slide_number'],
        ];
        if ($settings['layout'] == 'one') {
            ?>
            <section class="testimonial" data-rich='<?php echo wp_json_encode($option) ?>'>
            <?php echo '<div class="testimonial-carousel owl-carousel">';
            if ($settings['member_list']) {
                foreach ($settings['member_list'] as $members) {
                    echo '<div class="testimonial-item">
                        <div class="qoute"><i class="fa fa-quote-left"></i></div>
                        <div class="content">
                            <p>' . $members['member_info'] . '</p>
                        </div>
                        <div class="author">
                            <div class="img-box">
                                ' . get_that_image($members['member_photo']) . '
                            </div>
                            <div class="title">
                                <h5>' . $members['member_name'] . '</h5>
                                <p>' . $members['member_designation'] . '</p>
                            </div>
                        </div>
                    </div>';
                }
            }
            echo '</div>
        </section>';
        } elseif ($settings['layout'] == 'two') {
            ?>
        <div class="testimonial-style2" data-rich='<?php echo wp_json_encode($option) ?>'>
            <?php echo '<div class="testimonial-carousel2 owl-carousel">';
            if ($settings['member_list']) {
                foreach ($settings['member_list'] as $members) {
                    echo '<div class="testimonial-item">
                    <div class="content">
                        <div class="qoute"><i class="fa fa-quote-left"></i></div>
                        <p>' . $members['member_info'] . '</p>
                    </div>
                    <div class="author">
                        <div class="img-box">
                            ' . get_that_image($members['member_photo']) . '
                        </div>
                        <div class="title">
                            <h5>' . $members['member_name'] . '</h5>
                            <p>' . $members['member_designation'] . '</p>
                        </div>
                    </div>
                </div> ';
                }
            }
            echo '</div>  
        </div>';
        }else {
            echo '<div class="testimonial style-3">
                    <div class="row">';
            if ($settings['member_list']) {
                foreach ($settings['member_list'] as $members) {
                    echo '<article class="col-md-6 col-sm-6 col-xs-12">
                            <div class="testimonial-item">
                                <div class="qoute"><i class="fa fa-quote-left"></i></div>
                                <div class="content">
                                    <p>' . $members['member_info'] . '</p>
                                </div>
                                <div class="author">
                                    <div class="img-box">
                                         ' . get_that_image($members['member_photo']) . '
                                    </div>
                                    <div class="title">
                                        <h5>' . $members['member_name'] . '</h5>
                                        <p>' . $members['member_designation'] . '</p>
                                    </div>
                                </div>
                            </div> 
                        </article>';
                    }
                }
                echo '</div>                  
                </div>
                 ';
        }

    }

    protected function _content_template() {
    }



    protected function content_template() {}

    public function render_plain_content( $instance = [] ) {}

}
Plugin::instance()->widgets_manager->register_widget_type( new rich_testimonial() );
?>