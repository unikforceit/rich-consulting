<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class rich_location extends Widget_Base {

    public function get_name() {
        return 'rich-location';
    }

    public function get_title() {
        return __( 'Locations', 'rich-consulting' );
    }
    public function get_categories() {
        return [ 'richelement-addons' ];
    }
    public function get_icon() {
        return 'eicon-person';
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => __( 'Content', 'rich-consulting' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_responsive_control(
            'column',
            [
                'label' => __( 'Column Layout', 'rich-consulting' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '6',
                'options' => [
                    '1'  => __( '1 Column', 'rich-consulting' ),
                    '2' => __( '2 Column', 'rich-consulting' ),
                    '3' => __( '3 Column', 'rich-consulting' ),
                    '4' => __( '4 Column', 'rich-consulting' ),
                    '5' => __( '5 Column', 'rich-consulting' ),
                    '6' => __( '6 Column', 'rich-consulting' ),
                    '7' => __( '7 Column', 'rich-consulting' ),
                    '8' => __( '8 Column', 'rich-consulting' ),
                    '9' => __( '9 Column', 'rich-consulting' ),
                    '10' => __( '10 Column', 'rich-consulting' ),
                    '11' => __( '11 Column', 'rich-consulting' ),
                    '12' => __( '12 Column', 'rich-consulting' ),
                ],
            ]
        );
        $repeater = new \Elementor\Repeater();
        $repeater->add_control(
            'partner', [
                'label' => __( 'Photo', 'rich-consulting' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );
        $repeater->add_control(
            'title',
            [
                'label' => __( 'Title', 'rich-consulting' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __('New York', 'rich-consulting'),
            ]
        );
        $this->add_control(
            'partner',
            [
                'label' => __( 'Location List', 'rich-consulting' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'partner' => [
                            'url' => \Elementor\Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'partner' => [
                            'url' => \Elementor\Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'partner' => [
                            'url' => \Elementor\Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'partner' => [
                            'url' => \Elementor\Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'partner' => [
                            'url' => \Elementor\Utils::get_placeholder_image_src(),
                        ],
                    ],

                ],
            ]
        );
        $this->end_controls_section();
        $this->start_controls_section(
            'section_style',
            [
                'label' => __( 'Style', 'rich-consulting' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'title_color',
            [
                'label' => __( 'Title Color', 'rich-consulting' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .company-location .caption' => 'color: {{VALUE}}'
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'title_fonts',
                'label' => __( 'Title Typography', 'rich-consulting' ),
                'selector' => '{{WRAPPER}} .company-location .caption',
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'team_socials_bg',
                'label' => __( 'Team Social BG', 'rich-consulting' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .company-location .caption',
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'team_socials_bgh',
                'label' => __( 'Team Social BG', 'rich-consulting' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .company-location .overlay',
            ]
        );
        $this->add_responsive_control(
            'padding',
            [
                'label' => __( 'Padding', 'rich-consulting' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .company-location .caption' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
    echo '<div class="company-location">
                    <div class="row">';
            if ( $settings['partner'] ) {
                foreach ($settings['partner'] as $partner) {
                    echo'<div class="px-0 pr-0 col-md-'.$settings['column'].'" id="'.$partner['_id'].'">
                            <div class="img-box">
                                '.get_that_image($partner['partner']).'
                                <div class="overlay">
                                    <div class="content"><a data-group="1" href="'.$partner['partner']['url'].'" class="img-popup"><i class="fa fa-eye"></i></a></div>
                                </div>
                                <h2 class="caption">'.$partner['title'].'</h2>
                            </div>
                        </div>';
                        }
                    }
                echo'</div>
                </div>';
    }

    protected function _content_template() {
    }



    protected function content_template() {}

    public function render_plain_content( $instance = [] ) {}

}
Plugin::instance()->widgets_manager->register_widget_type( new rich_location() );
?>