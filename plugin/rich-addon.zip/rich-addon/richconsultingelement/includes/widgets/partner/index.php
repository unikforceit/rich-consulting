<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class rich_partner extends Widget_Base {

    public function get_name() {
        return 'rich-partner';
    }

    public function get_title() {
        return __( 'Partner', 'rich-consulting' );
    }
    public function get_categories() {
        return [ 'richelement-addons' ];
    }
    public function get_icon() {
        return 'eicon-person';
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => __( 'Content', 'rich-consulting' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        $repeater = new \Elementor\Repeater();
        $repeater->add_control(
            'partner', [
                'label' => __( 'Photo', 'rich-consulting' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );
        $repeater->add_control(
            'link', [
                'label' => __( 'Link', 'rich-consulting' ),
                'type' => \Elementor\Controls_Manager::URL,
                'show_external' => true,
                'default' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                ],
            ]
        );
        $this->add_control(
            'partner',
            [
                'label' => __( 'Partner List', 'rich-consulting' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'partner' => [
                            'url' => \Elementor\Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'partner' => [
                            'url' => \Elementor\Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'partner' => [
                            'url' => \Elementor\Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'partner' => [
                            'url' => \Elementor\Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'partner' => [
                            'url' => \Elementor\Utils::get_placeholder_image_src(),
                        ],
                    ],

                ],
            ]
        );
        $this->add_control(
            'item',
            [
                'label' => __( 'Slide Item', 'rich-consulting' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'size' => 6,
                ],
            ]
        );
        $this->end_controls_section();
        $this->start_controls_section(
            'section_style',
            [
                'label' => __( 'Style', 'rich-consulting' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'social_bg',
            [
                'label' => __( 'Hover BG', 'rich-consulting' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'after',
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'team_socials_bg',
                'label' => __( 'Team Social BG', 'rich-consulting' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .brand-logo .owl-nav button i',
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'team_socials_bgh',
                'label' => __( 'Team Social BG', 'rich-consulting' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .brand-logo .owl-nav button:hover i',
            ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
    echo '<section class="brand-logo" data-rich="'.$settings['item']['size'].'">
            <div class="partner-column">
                <ul class="brand-carousel owl-carousel">';
            if ( $settings['partner'] ) {
                foreach ($settings['partner'] as $partner) {
                    echo'<li><a  '.get_that_link($partner['link']).'> '.get_that_image($partner['partner']).'</a></li>';
                        }
                    }
            echo'</ul>
            </div>
    </section>
';
    }

    protected function _content_template() {
    }



    protected function content_template() {}

    public function render_plain_content( $instance = [] ) {}

}
Plugin::instance()->widgets_manager->register_widget_type( new rich_partner() );
?>