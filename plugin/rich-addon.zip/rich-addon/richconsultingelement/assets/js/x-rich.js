(function ($) {
"use strict";

    var RichGlobal = function ($scope, $) {

        // Js Start
            $('[data-background]').each(function() {
                $(this).css('background-image', 'url('+ $(this).attr('data-background') + ')');
            });
        $(".preloader").fadeOut();
        if($('.wow').length){
            new WOW({
                offset: 100,
                mobile: true
            }).init()
        }
        jQuery(window).on('scroll', function() {
            if (jQuery(window).scrollTop() > 250) {
                jQuery('.richconsulting-sticky-header').addClass('sticky-on')
            } else {
                jQuery('.richconsulting-sticky-header').removeClass('sticky-on')
            }
        });
        $(".richconsulting-icon-lightbox a").magnificPopup({
            type: 'iframe',
            iframe: {
                patterns: {
                    youtube: {
                        index: 'youtube.com/',
                        id: 'v=',
                        src: 'https://www.youtube.com/embed/%id%?autoplay=1'
                    },
                    vimeo: {
                        index: 'vimeo.com/',
                        id: '/',
                        src: '//player.vimeo.com/video/%id%?autoplay=1'
                    },
                    gmaps: {
                        index: '//maps.google.',
                        src: '%id%&output=embed'
                    }
                },
                srcAction: 'iframe_src',
            }
        });
        // Js End

    };

    var CDNavMenu = function ($scope, $) {

        $scope.find('.richconsulting-nav-builder').each(function () {
            var settings = $(this).data('rich');

        // Js Start
            $('.str-open_mobile_menu').on("click", function() {
                $('.str-mobile_menu_wrap').toggleClass("mobile_menu_on");
            });
            $('.str-open_mobile_menu').on('click', function () {
                $('body').toggleClass('mobile_menu_overlay_on');
            });
            if($('.str-mobile_menu li.dropdown ul').length){
                $('.str-mobile_menu li.dropdown').append('<div class="dropdown-btn"><span class="fa fa-angle-down"></span></div>');
                $('.str-mobile_menu li.dropdown .dropdown-btn').on('click', function() {
                    $(this).prev('ul').slideToggle(500);
                });
            }
        // Js End
        });

    };

    var RichTesti = function ($scope, $) {

        $scope.find('.testimonial').each(function () {
            var settings = $(this).data('rich');
            // Js Start
                $('.testimonial-carousel').owlCarousel({
                    loop: true,
                    items: settings['item'],
                    nav: true,
                    navText: [
                        '<i class="fa fa-angle-left"></i>',
                        '<i class="fa fa-angle-right"></i>'
                    ],
                    dots: false,
                    smartSpeed: 2000,
                    autoplay:true
                });
            // Js End
        });
        $scope.find('.testimonial-style2').each(function () {
            var settings = $(this).data('rich');
            // Js Start
            $('.testimonial-carousel2').owlCarousel({
                loop: true,
                items: settings['item'],
                nav: false,
                dots: true,
                smartSpeed: 2000,
                autoplay:true,
                margin: 20,
            });
            // Js End
        });

    };

    var RichCases = function ($scope, $) {

        $scope.find('.all-cause').each(function () {
            var settings = $(this).data('rich');

            $(".post-filter li").each(function(){
                $(this).on("click", function(){
                    $(this).siblings("li").removeClass("active");
                    $(this).addClass("active");
                });
            });
            var FilterContainer = $(".post-filter-container");
            var FilterItem = $(".post-filter-container .filter-container .filtr-item").length;
            console.log(FilterItem);
            if(FilterContainer.hasClass("has-filterizr") && FilterItem > 0){
                var filterized = $('.filter-container').filterizr({
                    gutterPixels: 20,
                    gridItemsSelector: '.filtr-item',
                });
            }
            // Js End
        });
    };
    var RichChose = function ($scope, $) {

        $scope.find('.why-chooseus').each(function () {
            var settings = $(this).data('rich');
            // Js Start
            $('.why-chosse-carousel').owlCarousel({
                loop: true,
                margin: 30,
                nav: false,
                smartSpeed: 2000,
                dots: true,
                autoplay:true,
                responsive: {
                    0:{
                        items:1,
                        loop:true,
                        dots:false
                    },
                    480:{
                        items:1,
                        loop:true,
                        dots:false
                    },
                    600:{
                        items:settings['item'],
                        loop:true,
                        dots:false
                    },
                    1000:{
                        items:settings['item'],
                        loop:true
                    }
                }
            });
            // Js End
        });
    };

    var RichPartner = function ($scope, $) {

        $scope.find('.brand-logo').each(function () {
            var settings = $(this).data('rich');
            // Js Start
            $(".brand-carousel").owlCarousel({
                autoplay: true,
                loop:true,
                dots:false,
                nav: true,
                navText: [
                    '<i class="fa fa-angle-left"></i>',
                    '<i class="fa fa-angle-right"></i>'
                ],
                responsive: {
                    0:{
                        items:1,
                    },
                    480:{
                        items:2,
                    },
                    768:{
                        items:settings,
                    },
                    1000:{
                        items:settings,
                    }
                }
            });
            // Js End
        });
    };

    var RichAddress = function ($scope, $) {

        $scope.find('.our-address').each(function () {
            var settings = $(this).data('rich');
            // Js Start
            $(".address-carousel").owlCarousel({
                autoplay: true,
                loop: true,
                margin: 30,
                smartSpeed:2000,
                nav: true,
                dots: false,
                navText: [
                    '<i class="fa fa-angle-left"></i>',
                    '<i class="fa fa-angle-right"></i>'
                ],
                responsive: {
                    0:{
                        items:1,
                    },
                    1000:{
                        items:settings['item'],
                    }
                }
            });
            // Js End
        });
    };



    $(window).on('elementor/frontend/init', function () {
        if (elementorFrontend.isEditMode()) {
            console.log('Elementor editor mod loaded');
            elementorFrontend.hooks.addAction('frontend/element_ready/global', RichGlobal);
            elementorFrontend.hooks.addAction('frontend/element_ready/nav-builder.default', CDNavMenu);
            elementorFrontend.hooks.addAction('frontend/element_ready/rich-testimonial.default', RichTesti);
            elementorFrontend.hooks.addAction('frontend/element_ready/cases-filter.default', RichCases);
            elementorFrontend.hooks.addAction('frontend/element_ready/feature-slider.default', RichChose);
            elementorFrontend.hooks.addAction('frontend/element_ready/rich-partner.default', RichPartner);
            elementorFrontend.hooks.addAction('frontend/element_ready/address-slider.default', RichAddress);
        }
        else {
            console.log('Elementor frontend mod loaded');
            elementorFrontend.hooks.addAction('frontend/element_ready/global', RichGlobal);
            elementorFrontend.hooks.addAction('frontend/element_ready/rich-testimonial.default', RichTesti);
            elementorFrontend.hooks.addAction('frontend/element_ready/cases-filter.default', RichCases);
            elementorFrontend.hooks.addAction('frontend/element_ready/feature-slider.default', RichChose);
            elementorFrontend.hooks.addAction('frontend/element_ready/rich-partner.default', RichPartner);
            elementorFrontend.hooks.addAction('frontend/element_ready/address-slider.default', RichAddress);
        }
    });
console.log('addon js loaded');
})(jQuery);