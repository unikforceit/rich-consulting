<?php

	class rich_custom_post_type {
		
		function __construct() {
			
			add_action('init', array(&$this,'rich_builder_post_type'));
			add_action('init', array(&$this,'create_builder_post_taxonomy'));
            add_action('init', array(&$this, 'create_services_cpt'));
            add_action('init', array(&$this, 'services_taxonomy'), 0);
            add_action('init', array(&$this, 'create_cases_cpt'));
            add_action('init', array(&$this, 'cases_taxonomy'), 0);

        }
	  // Builder Post Type
		function rich_builder_post_type() {
        $labels = array(
            'name' => __('Rich Builder', 'rich-consulting'),
            'singular_name' => __('Rich Builder', 'rich-consulting'),
            'add_new' => __('Add rich builder', 'rich-consulting'),
            'add_new_item' => __('Add rich builder', 'rich-consulting'),
            'edit_item' => __('Edit rich builder', 'rich-consulting'),
            'new_item' => __('New rich builder', 'rich-consulting'),
            'all_items' => __('All rich builder', 'rich-consulting'),
            'view_item' => __('View rich builder', 'rich-consulting'),
            'search_items' => __('Search rich builder', 'rich-consulting'),
            'not_found' => __('No rich builder found', 'rich-consulting'),
            'not_found_in_trash' => __('No portfolio found in the trash', 'rich-consulting'),
            'parent_item_colon' => '',
            'menu_name' => __('Rich Theme Builder', 'rich-consulting')
        );
        $args = array(
            'labels' => $labels,
            'public' => true,
            'menu_position' => 4,
            'menu_icon' => 'dashicons-admin-multisite',
            'supports' => array('title', 'editor', 'thumbnail', 'excerpt','elementor'),
            'has_archive' => false,
        );
            register_post_type('rich_builders', $args);
        }

        function create_builder_post_taxonomy() {
            $labels = array(
                'name' => __('Category', 'rich-consulting'),
                'singular_name' => __('Category', 'rich-consulting'),
                'search_items' => __('Search categories', 'rich-consulting'),
                'all_items' => __('Categories', 'rich-consulting'),
                'parent_item' => __('Parent category', 'rich-consulting'),
                'parent_item_colon' => __('Parent category:', 'rich-consulting'),
                'edit_item' => __('Edit category', 'rich-consulting'),
                'update_item' => __('Update category', 'rich-consulting'),
                'add_new_item' => __('Add category', 'rich-consulting'),
                'new_item_name' => __('New category', 'rich-consulting'),
                'menu_name' => __('Category', 'rich-consulting'),
            );
            $args = array(
                'labels' => $labels,
                'hierarchical' => true,
                'show_ui' => true,
                'show_admin_column' => true,
                'rewrite' => array('slug' => 'rich_builder_cat'),
            );
            register_taxonomy('rich_builder_cat', 'rich_builders', $args);
        }

        // Services Post type
        function create_services_cpt() {
            $labels = array(
                'name' => __('Service', 'rich-consulting'),
                'singular_name' => __('Service', 'rich-consulting'),
                'add_new' => __('Add service', 'rich-consulting'),
                'add_new_item' => __('Add service', 'rich-consulting'),
                'edit_item' => __('Edit service', 'rich-consulting'),
                'new_item' => __('New service', 'rich-consulting'),
                'all_items' => __('All service', 'rich-consulting'),
                'view_item' => __('View service', 'rich-consulting'),
                'search_items' => __('Search service', 'rich-consulting'),
                'not_found' => __('No service found', 'rich-consulting'),
                'not_found_in_trash' => __('No portfolio found in the trash', 'rich-consulting'),
                'parent_item_colon' => '',
                'supports' => array('post-formats'),
                'menu_name' => __('Services', 'rich-consulting')
            );
            $args = array(
                'labels' => $labels,
                'public' => true,
                'menu_position' => 5,
                'menu_icon' => 'dashicons-megaphone',
                'taxonomies' => array('service_category'),
                'supports' => array('title', 'editor', 'thumbnail', 'excerpt','elementor'),
                'has_archive' => true,
            );
            register_post_type('services', $args);
        }

        function services_taxonomy() {
            $labels = array(
                'name' => __('Category', 'rich-consulting'),
                'singular_name' => __('Category', 'rich-consulting'),
                'search_items' => __('Search categories', 'rich-consulting'),
                'all_items' => __('Categories', 'rich-consulting'),
                'parent_item' => __('Parent category', 'rich-consulting'),
                'parent_item_colon' => __('Parent category:', 'rich-consulting'),
                'edit_item' => __('Edit category', 'rich-consulting'),
                'update_item' => __('Update category', 'rich-consulting'),
                'add_new_item' => __('Add category', 'rich-consulting'),
                'new_item_name' => __('New category', 'rich-consulting'),
                'menu_name' => __('Category', 'rich-consulting'),
            );
            $args = array(
                'labels' => $labels,
                'hierarchical' => true,
                'show_ui' => true,
                'show_admin_column' => true,
                'rewrite' => array('slug' => 'service_category'),
            );
            register_taxonomy('service_category', 'services', $args);
        }

       // Case Post Type
        function create_cases_cpt() {
            $labels = array(
                'name' => __('Cases', 'rich-consulting'),
                'singular_name' => __('Case', 'rich-consulting'),
                'add_new' => __('Add case', 'rich-consulting'),
                'add_new_item' => __('Add case', 'rich-consulting'),
                'edit_item' => __('Edit case', 'rich-consulting'),
                'new_item' => __('New case', 'rich-consulting'),
                'all_items' => __('All case', 'rich-consulting'),
                'view_item' => __('View case', 'rich-consulting'),
                'search_items' => __('Search case', 'rich-consulting'),
                'not_found' => __('No case found', 'rich-consulting'),
                'not_found_in_trash' => __('No case found in the trash', 'rich-consulting'),
                'parent_item_colon' => '',
                'supports' => array('post-formats'),
                'menu_name' => __('Cases', 'rich-consulting')
            );
            $args = array(
                'labels' => $labels,
                'public' => true,
                'menu_position' => 6,
                'menu_icon' => 'dashicons-images-alt',
                'taxonomies' => array('case_category'),
                'supports' => array('title', 'editor', 'thumbnail', 'excerpt','elementor'),
                'has_archive' => true,
            );
            register_post_type('cases', $args);
        }

        function Cases_taxonomy() {
            $labels = array(
                'name' => __('Category', 'rich-consulting'),
                'singular_name' => __('Category', 'rich-consulting'),
                'search_items' => __('Search categories', 'rich-consulting'),
                'all_items' => __('Categories', 'rich-consulting'),
                'parent_item' => __('Parent category', 'rich-consulting'),
                'parent_item_colon' => __('Parent category:', 'rich-consulting'),
                'edit_item' => __('Edit category', 'rich-consulting'),
                'update_item' => __('Update category', 'rich-consulting'),
                'add_new_item' => __('Add category', 'rich-consulting'),
                'new_item_name' => __('New category', 'rich-consulting'),
                'menu_name' => __('Category', 'rich-consulting'),
            );
            $args = array(
                'labels' => $labels,
                'hierarchical' => true,
                'show_ui' => true,
                'show_admin_column' => true,
                'rewrite' => array('slug' => 'case_category'),
            );
            register_taxonomy('case_category', 'cases', $args);
        }
					
	}  

    new rich_custom_post_type();

